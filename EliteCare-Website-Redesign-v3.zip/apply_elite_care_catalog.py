"""Apply the Elite Care brand settings and service catalogue to an existing DB."""

from app import create_app
from catalog_update import sync_catalog


def main():
    app = create_app()
    with app.app_context():
        count = sync_catalog()
        print(f"Updated Elite Care settings and {count} services across 5 groups.")
        print("Existing users and bookings were kept; the previous services are inactive.")


if __name__ == "__main__":
    main()
