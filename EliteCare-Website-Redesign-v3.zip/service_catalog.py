"""Elite Care's public service groups and the services shown on the site."""

SERVICE_CATALOG = [
    {
        "name": "Cleaning Services",
        "slug": "cleaning-services",
        "tagline": "Fresh, hygienic spaces for every kind of property",
        "description": "Deep cleaning and surface care for homes, offices, and commercial properties.",
        "accent": "green",
        "services": [
            {
                "name": "Deep Cleaning & Sanitization",
                "slug": "deep-cleaning-sanitization",
                "summary": "Homes | Offices | Commercial",
                "description": "A detailed clean for the rooms and high-touch surfaces that need extra care. We tailor the visit to your property and sanitization requirements.",
                "includes": "Room-by-room deep clean\nKitchen and washroom detailing\nHigh-touch surface sanitization\nResidential and commercial visits",
                "icon": "sparkle",
                "image": "deep-cleaning.jpg",
                "featured": True,
            },
            {
                "name": "Floor & Surface Care",
                "slug": "floor-surface-care",
                "summary": "Marble | Tile | Carpet | Polishing",
                "description": "Care for the surfaces people see and use every day. The cleaning method is selected for the material and condition of each floor or surface.",
                "includes": "Marble and tile cleaning\nCarpet care\nSurface polishing\nMaterial-appropriate cleaning",
                "icon": "sparkle",
                "image": "floor-surface-care.jpg",
                "featured": True,
            },
        ],
    },
    {
        "name": "Technical Services",
        "slug": "technical-services",
        "tagline": "Skilled repairs, installation, and planned upkeep",
        "description": "Practical technical support for essential building systems and everyday repairs.",
        "accent": "blue",
        "services": [
            {
                "name": "Electrical & Plumbing",
                "slug": "electrical-plumbing",
                "summary": "Repair | Installation | Maintenance",
                "description": "Electrical and plumbing work for common property needs, from troubleshooting and repair to new fixture installation and routine maintenance.",
                "includes": "Electrical fault checks and repairs\nFixture and fitting installation\nPlumbing repairs\nPreventive maintenance",
                "icon": "gear",
                "image": "electrical-plumbing.svg",
                "featured": True,
            },
            {
                "name": "AC & HVAC Maintenance",
                "slug": "ac-hvac-maintenance",
                "summary": "Service | Installation | Repair",
                "description": "Air conditioning and HVAC support to help keep indoor spaces comfortable. Tell us about your unit and the issue, and we will arrange the right service.",
                "includes": "AC service and inspection\nInstallation support\nRepair and troubleshooting\nResidential and commercial systems",
                "icon": "gear",
                "image": "ac-hvac-maintenance.svg",
                "featured": True,
            },
        ],
    },
    {
        "name": "Maintenance Services",
        "slug": "maintenance-services",
        "tagline": "Reliable care for the details that keep buildings working",
        "description": "Coordinated maintenance for residential properties, offices, and commercial buildings.",
        "accent": "green",
        "services": [
            {
                "name": "Carpentry & Civil Works",
                "slug": "carpentry-civil-works",
                "summary": "Repairs | Fittings | Renovation",
                "description": "Carpentry and small civil works for repairs, fittings, and renovation projects. We confirm the scope after reviewing the property and requested work.",
                "includes": "Carpentry repairs and fittings\nMinor civil repairs\nDoor and fixture adjustments\nRenovation support",
                "icon": "gear",
                "image": "carpentry-civil-works.svg",
                "featured": False,
            },
            {
                "name": "Building Maintenance",
                "slug": "building-maintenance",
                "summary": "Total Facility Care",
                "description": "A single point of contact for planned building upkeep and day-to-day maintenance needs across residential and commercial facilities.",
                "includes": "Routine property inspections\nMinor repairs and upkeep\nCoordination across service trades\nResidential and commercial facilities",
                "icon": "office",
                "image": "building-maintenance.svg",
                "featured": True,
            },
            {
                "name": "Waterproofing",
                "slug": "waterproofing",
                "summary": "Roofs | Walls | Bathrooms",
                "description": "Waterproofing support for common leak-prone areas. We assess the affected surface and recommend a suitable repair approach for the property.",
                "includes": "Roof waterproofing\nWall leak treatment\nBathroom and wet-area sealing\nSite assessment and repair plan",
                "icon": "shield",
                "image": "waterproofing.svg",
                "featured": False,
            },
        ],
    },
    {
        "name": "Glass Cleaning",
        "slug": "glass-cleaning",
        "tagline": "Clear glass and clean facades, inside and out",
        "description": "Glass care for residences and businesses, from windows to showrooms and building facades.",
        "accent": "blue",
        "services": [
            {
                "name": "Glass & Facade Cleaning",
                "slug": "glass-facade-cleaning",
                "summary": "Windows | Showrooms | Buildings",
                "description": "Professional glass cleaning for windows, shopfronts, showrooms, and building facades, planned around the size and access needs of your property.",
                "includes": "Window and glass partition cleaning\nShowroom and shopfront glass\nFacade cleaning assessment\nInterior and exterior glass care",
                "icon": "office",
                "image": "glass-facade-cleaning.webp",
                "featured": True,
            },
        ],
    },
    {
        "name": "Painting & Renovation",
        "slug": "painting-renovation-services",
        "tagline": "Thoughtful updates for interiors and exteriors",
        "description": "Painting and renovation support to refresh a room, improve a finish, or update a property.",
        "accent": "green",
        "services": [
            {
                "name": "Painting & Renovation",
                "slug": "painting-renovation",
                "summary": "Interior | Exterior | Decorative",
                "description": "Painting and renovation services for interior and exterior spaces, including decorative finishes. Work is scoped to your property and preferred finish.",
                "includes": "Interior painting\nExterior painting\nDecorative finishes\nRenovation and surface preparation",
                "icon": "sparkle",
                "image": "painting-renovation.svg",
                "featured": True,
            },
        ],
    },
]


def iter_services():
    """Yield each service with its parent group's data and display order."""
    display_order = {
        name: order
        for order, name in enumerate(
            [
                "Cleaning Services",
                "Painting & Renovation",
                "Maintenance Services",
                "Glass Cleaning",
                "Technical Services",
            ],
            start=1,
        )
    }
    groups = sorted(SERVICE_CATALOG, key=lambda group: display_order[group["name"]])
    for group_order, group in enumerate(groups, start=1):
        for service_order, service in enumerate(group["services"], start=1):
            yield group_order, service_order, group, service
