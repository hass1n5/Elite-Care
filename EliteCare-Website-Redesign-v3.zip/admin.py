from datetime import datetime, timedelta, timezone
from urllib.parse import urlsplit

from flask import (
    Blueprint,
    abort,
    current_app,
    flash,
    redirect,
    render_template,
    request,
    url_for,
)
from sqlalchemy import func

import theming
from extensions import db
from models import (
    BOOKING_STATUSES,
    Booking,
    Category,
    ContentBlock,
    SEOPage,
    Service,
    Setting,
    Testimonial,
    User,
    slugify,
)
from security import admin_required, delete_image, save_image, validate_csrf

bp = Blueprint("admin", __name__, url_prefix="/admin")


@bp.before_request
@admin_required
def guard():
    return None


def _page():
    try:
        return max(1, int(request.args.get("page", 1)))
    except (TypeError, ValueError):
        return 1


def _form_ok(redirect_to):
    if validate_csrf():
        return None
    flash("Form expire ho gaya. Dobara koshish karein.", "error")
    return redirect(redirect_to)


def _int_or_none(raw):
    try:
        value = int(raw)
        return value if value >= 0 else None
    except (TypeError, ValueError):
        return None


# ------------------------------------------------------------- dashboard


@bp.get("/")
def dashboard():
    now = datetime.now(timezone.utc)
    month_start = datetime(now.year, now.month, 1, tzinfo=timezone.utc)
    week_start = now - timedelta(days=7)

    total = db.session.scalar(db.select(func.count(Booking.id))) or 0
    new_count = db.session.scalar(
        db.select(func.count(Booking.id)).where(Booking.status == "new")
    ) or 0
    this_week = db.session.scalar(
        db.select(func.count(Booking.id)).where(Booking.created_at >= week_start)
    ) or 0
    completed = db.session.scalar(
        db.select(func.count(Booking.id)).where(Booking.status == "completed")
    ) or 0
    clients = db.session.scalar(
        db.select(func.count(User.id)).where(User.role == "client")
    ) or 0
    revenue = db.session.scalar(
        db.select(func.coalesce(func.sum(Booking.quoted_price), 0)).where(
            Booking.status == "completed", Booking.created_at >= month_start
        )
    ) or 0

    status_rows = db.session.execute(
        db.select(Booking.status, func.count(Booking.id)).group_by(Booking.status)
    ).all()

    top_rows = db.session.execute(
        db.select(Service.name, func.count(Booking.id).label("n"))
        .join(Booking, Booking.service_id == Service.id)
        .group_by(Service.id)
        .order_by(func.count(Booking.id).desc())
        .limit(6)
    ).all()

    # Bookings per day for the last 14 days.
    days, counts = [], []
    for offset in range(13, -1, -1):
        day = (now - timedelta(days=offset)).date()
        days.append(day.strftime("%d %b"))
        counts.append(
            db.session.scalar(
                db.select(func.count(Booking.id)).where(
                    func.date(Booking.created_at) == day.isoformat()
                )
            )
            or 0
        )

    recent = db.session.scalars(
        db.select(Booking).order_by(Booking.created_at.desc()).limit(8)
    ).all()

    return render_template(
        "admin/dashboard.html",
        page_title="Overview",
        stats={
            "total": total,
            "new": new_count,
            "week": this_week,
            "completed": completed,
            "clients": clients,
            "revenue": revenue,
        },
        breakdown={s: c for s, c in status_rows},
        trend={"labels": days, "values": counts},
        top_services=[{"name": r[0], "count": int(r[1])} for r in top_rows],
        recent=recent,
        statuses=BOOKING_STATUSES,
    )


# -------------------------------------------------------------- bookings


@bp.get("/bookings")
def bookings():
    q = (request.args.get("q") or "").strip()
    status = request.args.get("status") or ""

    query = db.select(Booking)
    if q:
        like = f"%{q}%"
        query = query.where(
            db.or_(
                Booking.reference.ilike(like),
                Booking.name.ilike(like),
                Booking.phone.ilike(like),
                Booking.city.ilike(like),
            )
        )
    if status in BOOKING_STATUSES:
        query = query.where(Booking.status == status)

    pagination = db.paginate(
        query.order_by(Booking.created_at.desc()),
        page=_page(),
        per_page=current_app.config["PER_PAGE"],
        error_out=False,
    )

    return render_template(
        "admin/bookings.html",
        page_title="Bookings",
        pagination=pagination,
        statuses=BOOKING_STATUSES,
        filters={"q": q, "status": status},
    )


# -------------------------------------------------------------- services


@bp.get("/services")
def services():
    categories = db.session.scalars(
        db.select(Category).order_by(Category.sort_order)
    ).all()
    return render_template(
        "admin/services.html",
        page_title="Services",
        categories=categories,
        services=db.session.scalars(
            db.select(Service).order_by(Service.category_id, Service.sort_order)
        ).all(),
    )


@bp.post("/services/save")
def save_service():
    bail = _form_ok(url_for("admin.services"))
    if bail:
        return bail

    service_id = _int_or_none(request.form.get("id"))
    service = db.session.get(Service, service_id) if service_id else None

    name = (request.form.get("name") or "").strip()
    category_id = _int_or_none(request.form.get("category_id"))

    if not name or not category_id:
        flash("Service ka naam aur category zaroori hai.", "error")
        return redirect(url_for("admin.services"))

    if service is None:
        service = Service()
        db.session.add(service)

    slug = (request.form.get("slug") or "").strip() or slugify(name)
    clash = db.session.scalar(db.select(Service).filter_by(slug=slug))
    if clash and clash.id != service.id:
        slug = f"{slug}-{db.session.scalar(db.select(func.count(Service.id))) + 1}"

    service.name = name[:120]
    service.slug = slug[:140]
    service.category_id = category_id
    service.summary = (request.form.get("summary") or "").strip()[:300]
    service.description = (request.form.get("description") or "").strip()
    service.includes = (request.form.get("includes") or "").strip()
    service.price_from = _int_or_none(request.form.get("price_from")) or 0
    service.old_price = _int_or_none(request.form.get("old_price"))
    service.duration = (request.form.get("duration") or "").strip()[:60]
    service.icon = (request.form.get("icon") or "spray").strip()[:40]
    service.sort_order = _int_or_none(request.form.get("sort_order")) or 0
    service.is_featured = request.form.get("is_featured") == "on"
    service.is_active = request.form.get("is_active") == "on"

    upload = request.files.get("image")
    if upload and upload.filename:
        try:
            stored = save_image(upload, prefix="service")
        except ValueError as err:
            flash(str(err), "error")
            return redirect(url_for("admin.services"))
        delete_image(service.image)
        service.image = stored

    db.session.commit()
    flash(f"'{service.name}' save ho gaya.", "info")
    return redirect(url_for("admin.services"))


@bp.post("/services/<int:service_id>/duplicate")
def duplicate_service(service_id):
    """Copy a service so a similar one is three fields away, not twelve."""
    bail = _form_ok(url_for("admin.services"))
    if bail:
        return bail

    source = db.session.get(Service, service_id)
    if source is None:
        flash("Yeh service nahi mili.", "error")
        return redirect(url_for("admin.services"))

    name = f"{source.name} (copy)"[:120]
    slug = slugify(name)
    n = 2
    while db.session.scalar(db.select(Service).filter_by(slug=slug)):
        slug = f"{slugify(source.name)}-copy-{n}"
        n += 1

    copy = Service(
        category_id=source.category_id,
        name=name,
        slug=slug[:140],
        summary=source.summary,
        description=source.description,
        includes=source.includes,
        price_from=source.price_from,
        old_price=source.old_price,
        duration=source.duration,
        icon=source.icon,
        rating=source.rating,
        is_featured=False,
        is_active=False,  # off until the copy has been edited
        sort_order=source.sort_order + 1,
    )
    db.session.add(copy)
    db.session.commit()

    flash(f"'{source.name}' ki copy ban gayi — naam aur qeemat badal kar live karein.", "info")
    return redirect(url_for("admin.services"))


@bp.post("/categories/save")
def save_category():
    bail = _form_ok(url_for("admin.services"))
    if bail:
        return bail

    category_id = _int_or_none(request.form.get("id"))
    category = db.session.get(Category, category_id) if category_id else None

    name = (request.form.get("name") or "").strip()
    if not name:
        flash("Category ka naam zaroori hai.", "error")
        return redirect(url_for("admin.services"))

    if category is None:
        category = Category()
        db.session.add(category)

    slug = (request.form.get("slug") or "").strip() or slugify(name)
    clash = db.session.scalar(db.select(Category).filter_by(slug=slug))
    if clash and clash.id != category.id:
        slug = f"{slug}-2"

    category.name = name[:90]
    category.slug = slug[:90]
    category.tagline = (request.form.get("tagline") or "").strip()[:200]
    category.description = (request.form.get("description") or "").strip()
    category.accent = (request.form.get("accent") or "green").strip()[:20]
    category.sort_order = _int_or_none(request.form.get("sort_order")) or 0

    db.session.commit()
    flash(f"'{category.name}' save ho gayi.", "info")
    return redirect(url_for("admin.services"))


# --------------------------------------------------------------- clients


@bp.get("/clients")
def clients():
    q = (request.args.get("q") or "").strip()

    query = db.select(User).where(User.role == "client")
    if q:
        like = f"%{q}%"
        query = query.where(
            db.or_(User.name.ilike(like), User.email.ilike(like), User.phone.ilike(like))
        )

    pagination = db.paginate(
        query.order_by(User.created_at.desc()),
        page=_page(),
        per_page=current_app.config["PER_PAGE"],
        error_out=False,
    )
    return render_template(
        "admin/clients.html",
        page_title="Clients",
        pagination=pagination,
        filters={"q": q},
    )


@bp.get("/team")
def team():
    members = db.session.scalars(
        db.select(User).where(User.role == "admin").order_by(User.name)
    ).all()
    return render_template("admin/team.html", page_title="Admin users", members=members)


# ---------------------------------------------------------- testimonials


@bp.get("/reviews")
def reviews():
    items = db.session.scalars(
        db.select(Testimonial).order_by(Testimonial.id.desc())
    ).all()
    return render_template("admin/reviews.html", page_title="Reviews", items=items)


@bp.post("/reviews/save")
def save_review():
    bail = _form_ok(url_for("admin.reviews"))
    if bail:
        return bail

    review_id = _int_or_none(request.form.get("id"))
    review = db.session.get(Testimonial, review_id) if review_id else None

    name = (request.form.get("name") or "").strip()
    body = (request.form.get("body") or "").strip()
    if not name or not body:
        flash("Customer ka naam aur review zaroori hai.", "error")
        return redirect(url_for("admin.reviews"))

    if review is None:
        review = Testimonial()
        db.session.add(review)

    review.name = name[:90]
    review.city = (request.form.get("city") or "").strip()[:80]
    review.service = (request.form.get("service") or "").strip()[:120]
    review.rating = min(5, max(1, _int_or_none(request.form.get("rating")) or 5))
    review.body = body[:800]
    review.is_published = request.form.get("is_published") == "on"

    db.session.commit()
    flash("Review save ho gaya.", "info")
    return redirect(url_for("admin.reviews"))


# --------------------------------------------------------------- settings


@bp.get("/settings")
def settings():
    return render_template(
        "admin/settings.html",
        page_title="Site settings",
        s=Setting.all_as_dict(),
    )


@bp.post("/settings")
def save_settings():
    bail = _form_ok(url_for("admin.settings"))
    if bail:
        return bail

    text_fields = [
        "brand_name", "tagline", "whatsapp_number", "phone", "phone_alt",
        "email", "website", "ceo_name", "ceo_title", "address", "city", "hours", "facebook", "instagram",
        "hero_title", "hero_subtitle", "about_body", "map_embed",
        "stat_rating", "stat_jobs", "stat_staff", "stat_warranty",
        "chat_agent", "chat_role", "chat_reply_time", "chat_greeting", "chat_away",
        "seo_title", "seo_description", "seo_keywords",
        "google_site_verification", "bing_site_verification",
    ]
    for field in text_fields:
        if field in request.form:
            Setting.put(field, (request.form.get(field) or "").strip())

    # Appearance — only accept keys that exist in the catalogue.
    if "theme" in request.form:
        Setting.put("theme", theming.get_theme(request.form.get("theme"))["key"])

    for field, fallback in (
        ("font_heading", theming.DEFAULT_HEADING_FONT),
        ("font_body", theming.DEFAULT_BODY_FONT),
    ):
        if field in request.form:
            chosen = (request.form.get(field) or "").strip()
            Setting.put(field, chosen if chosen in theming.FONT_MAP else fallback)

    if "chat_form" in request.form:
        Setting.put("chat_enabled", "1" if request.form.get("chat_enabled") == "on" else "0")

    if "robots_policy" in request.form:
        robots_policy = (request.form.get("robots_policy") or "index,follow").strip()
        Setting.put(
            "robots_policy",
            robots_policy if robots_policy in {"index,follow", "noindex,nofollow"} else "index,follow",
        )

    for field, prefix in (("logo", "logo"), ("favicon", "favicon"), ("hero_image", "hero"), ("seo_og_image", "seo")):
        upload = request.files.get(field)
        if upload and upload.filename:
            try:
                stored = save_image(upload, prefix=prefix)
            except ValueError as err:
                flash(str(err), "error")
                return redirect(url_for("admin.settings"))
            delete_image(Setting.get(field))
            Setting.put(field, stored)

    for field in ("logo", "favicon", "hero_image", "seo_og_image"):
        if request.form.get(f"remove_{field}") == "on":
            delete_image(Setting.get(field))
            Setting.put(field, "")

    db.session.commit()
    flash("Settings save ho gayi.", "info")
    return redirect(url_for("admin.settings"))


# -------------------------------------------------------- homepage blocks

BLOCK_TYPES = {
    "text_image": "Text & Image",
    "feature_list": "Feature List",
    "cta": "Call to Action",
}


def _safe_content_url(raw):
    value = (raw or "").strip()[:255]
    if not value:
        return ""
    if value.startswith("/") and not value.startswith("//"):
        return value
    parsed = urlsplit(value)
    if parsed.scheme in {"http", "https", "mailto", "tel"}:
        return value if parsed.scheme in {"mailto", "tel"} or parsed.netloc else None
    return None


@bp.get("/blocks")
def blocks():
    items = db.session.scalars(
        db.select(ContentBlock).order_by(ContentBlock.sort_order, ContentBlock.id)
    ).all()
    return render_template(
        "admin/blocks.html",
        page_title="Home page blocks",
        items=items,
        block_types=BLOCK_TYPES,
    )


@bp.route("/blocks/new", methods=["GET", "POST"])
@bp.route("/blocks/<int:block_id>/edit", methods=["GET", "POST"])
def edit_block(block_id=None):
    block = db.session.get(ContentBlock, block_id) if block_id else None
    if block_id and block is None:
        abort(404)

    if request.method == "POST":
        bail = _form_ok(url_for("admin.blocks"))
        if bail:
            return bail

        block_type = (request.form.get("block_type") or "").strip()
        title = (request.form.get("title") or "").strip()
        if block_type not in BLOCK_TYPES or len(title) < 2:
            flash("Block type chunein aur kam az kam 2 haroof ka title likhein.", "error")
            return redirect(request.url)

        button_label = (request.form.get("button_label") or "").strip()[:80]
        button_url = _safe_content_url(request.form.get("button_url"))
        if request.form.get("button_url", "").strip() and button_url is None:
            flash("Button link /, http(s), tel, ya mailto link hona chahiye.", "error")
            return redirect(request.url)

        if block is None:
            block = ContentBlock()
            db.session.add(block)

        block.block_type = block_type
        block.eyebrow = (request.form.get("eyebrow") or "").strip()[:120]
        block.title = title[:160]
        block.body = (request.form.get("body") or "").strip()[:5000]
        block.items = (request.form.get("items") or "").strip()[:5000]
        block.button_label = button_label
        block.button_url = button_url or ""
        block.sort_order = _int_or_none(request.form.get("sort_order")) or 0
        block.is_active = request.form.get("is_active") == "on"

        upload = request.files.get("image")
        if upload and upload.filename:
            try:
                stored = save_image(upload, prefix="block")
            except ValueError as err:
                db.session.rollback()
                flash(str(err), "error")
                return redirect(request.url)
            delete_image(block.image)
            block.image = stored
        elif request.form.get("remove_image") == "on":
            delete_image(block.image)
            block.image = None

        db.session.commit()
        flash("Homepage block save ho gaya.", "info")
        return redirect(url_for("admin.blocks"))

    return render_template(
        "admin/block_edit.html",
        page_title="Edit home page block" if block else "Add home page block",
        block=block,
        block_types=BLOCK_TYPES,
        selected_type=(block.block_type if block else request.args.get("type", "text_image")),
    )


@bp.post("/blocks/<int:block_id>/delete")
def delete_block(block_id):
    bail = _form_ok(url_for("admin.blocks"))
    if bail:
        return bail
    block = db.session.get(ContentBlock, block_id)
    if block is None:
        abort(404)
    delete_image(block.image)
    db.session.delete(block)
    db.session.commit()
    flash("Homepage block delete ho gaya.", "info")
    return redirect(url_for("admin.blocks"))


# --------------------------------------------------------------------- SEO

def _seo_page_catalog():
    pages = [
        ("home", "Home page", url_for("public.home")),
        ("about", "About page", url_for("public.about")),
        ("services", "Services overview", url_for("public.services")),
        ("contact", "Contact page", url_for("public.contact")),
    ]
    categories = db.session.scalars(db.select(Category).order_by(Category.sort_order)).all()
    pages.extend(
        (f"category:{category.slug}", f"Category: {category.name}",
         url_for("public.category_detail", slug=category.slug))
        for category in categories if category.active_services
    )
    services = db.session.scalars(
        db.select(Service).where(Service.is_active.is_(True)).order_by(Service.name)
    ).all()
    pages.extend(
        (f"service:{service.slug}", f"Service: {service.name}",
         url_for("public.service_detail", slug=service.slug))
        for service in services
    )
    return pages


@bp.route("/seo", methods=["GET", "POST"])
def seo():
    if request.method == "POST":
        bail = _form_ok(url_for("admin.seo"))
        if bail:
            return bail

        limits = {"seo_title": 180, "seo_description": 320, "seo_keywords": 500,
                  "google_site_verification": 250, "bing_site_verification": 250}
        for field, limit in limits.items():
            Setting.put(field, (request.form.get(field) or "").strip()[:limit])

        robots_policy = (request.form.get("robots_policy") or "index,follow").strip()
        Setting.put("robots_policy", robots_policy if robots_policy in {"index,follow", "noindex,nofollow"} else "index,follow")

        upload = request.files.get("seo_og_image")
        if upload and upload.filename:
            try:
                stored = save_image(upload, prefix="seo")
            except ValueError as err:
                db.session.rollback()
                flash(str(err), "error")
                return redirect(url_for("admin.seo"))
            delete_image(Setting.get("seo_og_image"))
            Setting.put("seo_og_image", stored)
        elif request.form.get("remove_seo_og_image") == "on":
            delete_image(Setting.get("seo_og_image"))
            Setting.put("seo_og_image", "")

        db.session.commit()
        flash("SEO defaults save ho gaye.", "info")
        return redirect(url_for("admin.seo"))

    pages = _seo_page_catalog()
    return render_template(
        "admin/seo.html",
        page_title="SEO settings",
        s=Setting.all_as_dict(),
        pages=pages,
        seo_rows={key: db.session.get(SEOPage, key) for key, _label, _url in pages},
    )


@bp.route("/seo/<path:page_key>", methods=["GET", "POST"])
def edit_seo_page(page_key):
    page = next((row for row in _seo_page_catalog() if row[0] == page_key), None)
    if page is None:
        abort(404)

    record = db.session.get(SEOPage, page_key)
    if request.method == "POST":
        bail = _form_ok(url_for("admin.edit_seo_page", page_key=page_key))
        if bail:
            return bail

        canonical = (request.form.get("canonical_url") or "").strip()[:500]
        if canonical:
            parsed = urlsplit(canonical)
            if parsed.scheme not in {"http", "https"} or not parsed.netloc:
                flash("Canonical URL ko mukammal https:// address dein.", "error")
                return redirect(request.url)

        if record is None:
            record = SEOPage(page_key=page_key)
            db.session.add(record)
        record.title = (request.form.get("title") or "").strip()[:180]
        record.description = (request.form.get("description") or "").strip()[:320]
        record.keywords = (request.form.get("keywords") or "").strip()[:500]
        record.canonical_url = canonical
        record.noindex = request.form.get("noindex") == "on"

        upload = request.files.get("og_image")
        if upload and upload.filename:
            try:
                stored = save_image(upload, prefix="seo")
            except ValueError as err:
                db.session.rollback()
                flash(str(err), "error")
                return redirect(request.url)
            delete_image(record.og_image)
            record.og_image = stored
        elif request.form.get("remove_og_image") == "on":
            delete_image(record.og_image)
            record.og_image = None

        db.session.commit()
        flash("Page SEO save ho gayi.", "info")
        return redirect(url_for("admin.seo"))

    return render_template(
        "admin/seo_page.html",
        page_title="Edit page SEO",
        page=page,
        record=record,
    )
