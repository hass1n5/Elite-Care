"""Synchronize the Elite Care services without removing booking history."""

from app import DEFAULT_SETTINGS
from extensions import db
from models import Category, Service, Setting
from service_catalog import iter_services


def sync_catalog():
    """Deactivate the previous catalogue and upsert the nine new services."""
    db.create_all()

    for service in db.session.scalars(db.select(Service)).all():
        service.is_active = False
        service.is_featured = False

    count = 0
    for group_order, service_order, group, item in iter_services():
        category = db.session.scalar(
            db.select(Category).filter_by(slug=group["slug"])
        )
        if category is None:
            category = Category(slug=group["slug"], name=group["name"])
            db.session.add(category)

        category.name = group["name"]
        category.tagline = group["tagline"]
        category.description = group["description"]
        category.accent = group["accent"]
        category.sort_order = group_order
        db.session.flush()

        service = db.session.scalar(
            db.select(Service).filter_by(slug=item["slug"])
        )
        if service is None:
            service = Service(slug=item["slug"], name=item["name"])
            db.session.add(service)

        service.category_id = category.id
        service.name = item["name"]
        service.summary = item["summary"]
        service.description = item["description"]
        service.includes = item["includes"]
        service.price_from = 0
        service.old_price = None
        service.duration = "By assessment"
        service.icon = item["icon"]
        service.image = None
        service.rating = 0
        service.is_featured = item["featured"]
        service.is_active = True
        service.sort_order = service_order
        count += 1

    for key, value in DEFAULT_SETTINGS.items():
        Setting.put(key, value)

    db.session.commit()
    return count
