"""Prepare the Elite Care production database and service catalogue."""

import os

from app import create_app
from catalog_update import sync_catalog
from extensions import db
from models import User


def require_env(name):
    value = (os.environ.get(name) or "").strip()
    if not value:
        raise SystemExit(f"Missing required environment variable: {name}")
    return value


def setup():
    os.environ.setdefault("FLASK_ENV", "production")
    app = create_app("production")
    with app.app_context():
        db.create_all()

        # Keep all existing accounts. Create a production admin only when none exists.
        admin_count = db.session.scalar(
            db.select(db.func.count(User.id)).where(User.role == "admin")
        ) or 0
        admin_details = None
        if admin_count == 0:
            email = require_env("ADMIN_EMAIL").lower()
            password = require_env("ADMIN_PASSWORD")
            if len(password) < 12:
                raise SystemExit("ADMIN_PASSWORD must be at least 12 characters long.")
            name = (os.environ.get("ADMIN_NAME") or "Elite Care Admin").strip()[:90]
            if db.session.scalar(db.select(User).filter_by(email=email)):
                raise SystemExit("ADMIN_EMAIL already belongs to a non-admin account.")
            admin_details = (email, password, name)

        count = sync_catalog()
        if admin_details:
            email, password, name = admin_details
            admin = User(name=name, email=email, role="admin")
            admin.set_password(password)
            db.session.add(admin)
            db.session.commit()

        print("Elite Care production database ready.")
        print(f"Services synchronized: {count}")
        print("Existing user accounts and booking history were kept.")


if __name__ == "__main__":
    setup()
