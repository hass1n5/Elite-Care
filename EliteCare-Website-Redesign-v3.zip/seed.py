"""Create a development database for Elite Care.

    python seed.py            # seed an empty database
    python seed.py --reset    # replace the local database with a fresh one

For an existing site database, use apply_elite_care_catalog.py instead. That
command keeps users and bookings while adding the new service catalogue.
"""

import sys

from app import create_app
from catalog_update import sync_catalog
from extensions import db
from models import User


def seed(reset=False):
    app = create_app()
    with app.app_context():
        if reset:
            db.drop_all()

        db.create_all()
        if db.session.scalar(db.select(db.func.count(User.id))):
            print("Database already has users. Use apply_elite_care_catalog.py to update its catalogue.")
            return

        admin = User(
            name="Site Admin",
            email="admin@elitecare.com.pk",
            phone="0306 3911887",
            city="Lahore",
            role="admin",
        )
        admin.set_password("admin1234")
        db.session.add(admin)
        db.session.flush()

        sync_catalog()
        db.session.commit()
        print("Elite Care catalogue is ready.")
        print("  Services: 9 across 5 groups")
        print("  Local admin: admin@elitecare.com.pk / admin1234")


if __name__ == "__main__":
    seed(reset="--reset" in sys.argv)
