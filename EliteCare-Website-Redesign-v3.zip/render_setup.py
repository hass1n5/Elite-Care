"""Initialize a Render preview without resetting data on every start."""

import os

from app import DEFAULT_SETTINGS, create_app
from catalog_update import sync_catalog
from extensions import db
from models import Service, Setting, User


def require_env(name):
    value = (os.environ.get(name) or "").strip()
    if not value:
        raise SystemExit(f"Missing required environment variable: {name}")
    return value


def setup():
    app = create_app("production")
    with app.app_context():
        db.create_all()

        admin_count = db.session.scalar(
            db.select(db.func.count(User.id)).where(User.role == "admin")
        ) or 0
        if admin_count == 0:
            email = require_env("ADMIN_EMAIL").lower()
            password = require_env("ADMIN_PASSWORD")
            if len(password) < 12:
                raise SystemExit("ADMIN_PASSWORD must be at least 12 characters long.")
            if db.session.scalar(db.select(User).filter_by(email=email)):
                raise SystemExit("ADMIN_EMAIL already belongs to a non-admin account.")
            admin = User(
                name=(os.environ.get("ADMIN_NAME") or "Elite Care Admin").strip()[:90],
                email=email,
                role="admin",
            )
            admin.set_password(password)
            db.session.add(admin)

        service_count = db.session.scalar(
            db.select(db.func.count(Service.id))
        ) or 0
        if service_count == 0:
            # First start on the free preview (or after its temporary SQLite
            # filesystem resets): seed the catalogue and its default settings.
            synced = sync_catalog()
            service_count = synced
        else:
            # Keep administrator-edited settings on later process restarts.
            for key, value in DEFAULT_SETTINGS.items():
                if db.session.get(Setting, key) is None:
                    Setting.put(key, value)
            db.session.commit()

        print("Elite Care preview database ready.")
        print(f"Active services: {service_count}")


if __name__ == "__main__":
    setup()
