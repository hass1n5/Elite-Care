"""Create the new homepage block and page SEO tables on an existing install."""

from app import create_app
from extensions import db


def main():
    app = create_app()
    with app.app_context():
        db.create_all()
    print("Homepage block and SEO tables are ready; existing records were left in place.")


if __name__ == "__main__":
    main()
