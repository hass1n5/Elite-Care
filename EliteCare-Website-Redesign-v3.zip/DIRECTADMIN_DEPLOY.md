# Elite Care — DirectAdmin / Passenger deployment

## Python App settings

Use these values in **Setup Python App** (paths vary by hosting account):

- Python version: 3.11 or newer
- Application root: the folder containing `app.py` and `passenger_wsgi.py`
- Application URL: `https://www.elitecare.com.pk/`
- Application startup file: `passenger_wsgi.py`
- Application entry point: `application`

Do not point the app at the ZIP's parent folder. The application root must be the
`servicexpert` folder itself (or the folder that contains `app.py` and
`passenger_wsgi.py`).

## Environment variables

Set these in DirectAdmin's Python App environment section before first start:

- `FLASK_ENV=production`
- `SESSION_COOKIE_SECURE=1`
- `SECRET_KEY=<long-random-secret>`
- `ADMIN_EMAIL=<your-admin-email>`
- `ADMIN_PASSWORD=<a-strong-password-at-least-12-characters>`
- optional: `ADMIN_NAME=Site Admin`

For SQLite, no `DATABASE_URL` is required. The default database is `sparkle.db`
in the application root. If MySQL/PostgreSQL is used later, set `DATABASE_URL`.

## Install packages

Activate the virtualenv shown by DirectAdmin, then from the app root run:

```bash
pip install -r requirements.txt
python production_setup.py
```

`production_setup.py` synchronizes the Elite Care settings and nine-service
catalogue. Existing users and bookings are kept; an admin is created only if
the database has none. It does not create demo clients or bookings.

For an existing Elite Care deployment receiving only the homepage block and
SEO update, run this instead from the app root:

```bash
python update_content_seo.py
```

This creates any missing database tables for blocks and SEO. It does not
resynchronize settings or services and leaves existing user, booking, and
review data in place.

## Restart

Use DirectAdmin's **Restart** button after installation/bootstrap. Then verify:

- `/healthz` returns JSON with `status: ok`
- `/` loads the frontend
- `/services` loads the service catalogue
- `/admin/login` loads the admin login
- log in with `ADMIN_EMAIL` / `ADMIN_PASSWORD`
- submit one test booking and confirm it appears under Admin → Bookings

## Common 404 cause

If DirectAdmin shows its own 404 rather than the website's styled 404 page, the
request is not reaching Flask. Re-check Application URL, Application root,
startup file `passenger_wsgi.py`, entry point `application`, and restart the app.
