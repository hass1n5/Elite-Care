# Elite Care Website Update

- Rebranded the site and its public contact details for Elite Care.
- Replaced the cleaning/pest-control catalogue with five service groups and nine requested services.
- Added quote-based service pages and removed unsupported prices, ratings, and reviews from public pages.
- Reworked desktop and mobile home pages, service cards, navigation, and page styling.
- Replaced the three hero image assets and added service-specific visual assets.
- Added Elite Care logo and favicon SVGs.
- Added a catalogue sync command that keeps existing user accounts and booking history.
